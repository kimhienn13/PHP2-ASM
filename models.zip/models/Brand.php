<?php

/**
 * Brand Model xử lý dữ liệu cho bảng 'brands'
 * Kế thừa các phương thức từ lớp Model cơ sở
 */
class Brand extends Model {
    protected $table = 'brands';

    /**
     * Lấy danh sách thương hiệu có phân trang và tìm kiếm
     * Đã đặt giá trị mặc định cho tham số để tránh lỗi ArgumentCountError
     */
    public function list($page = 1, $limit = 10, $search = '') {
        return $this->paginate(
            $this->table,
            $page,
            $limit,
            $search,
            [],         
            'name'      
        );
    }

    /**
     * Lấy thông tin chi tiết một thương hiệu
     */
    public function show($id) {
        $sql = "SELECT * FROM {$this->table} WHERE id = ? AND deleted_at IS NULL LIMIT 1";
        return $this->query($sql, [$id])->fetch();
    }

    /**
     * Kiểm tra tên thương hiệu đã tồn tại chưa (loại trừ các bản ghi đã xóa mềm)
     */
    public function exists($name, $excludeId = null) {
        return $this->checkExists($this->table, 'name', $name, $excludeId);
    }

    /**
     * Thêm thương hiệu mới
     */
    public function create($data) {
        $sql = "INSERT INTO {$this->table} (name, image, description) VALUES (:name, :image, :description)";
        return $this->query($sql, [
            'name'        => $data['name'],
            'image'       => $data['image'] ?? null,
            'description' => $data['description'] ?? null
        ]);
    }

    /**
     * Cập nhật thương hiệu
     * Hàm này được thiết kế để nhận 2 tham số ($id, $data) 
     * nhằm khớp với logic xử lý của BrandController hiện tại.
     */
    public function update($id, $data) {
        $sql = "UPDATE {$this->table} SET 
                name = :name, 
                image = :image, 
                description = :description 
                WHERE id = :id";
        
        return $this->query($sql, [
            'id'          => $id,
            'name'        => $data['name'],
            'image'       => $data['image'] ?? null,
            'description' => $data['description'] ?? null
        ]);
    }

    /**
     * Xóa mềm thương hiệu
     */
    public function delete($id) {
        $sql = "UPDATE {$this->table} SET deleted_at = NOW() WHERE id = ?";
        return $this->query($sql, [$id]);
    }
}