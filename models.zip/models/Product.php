<?php

/**
 * Product Model xử lý dữ liệu cho bảng 'products'
 * Kế thừa từ Model cơ sở để sử dụng các hàm paginate, query và checkExists
 */
class Product extends Model {
    protected $table = 'products';

    /**
     * Lấy danh sách sản phẩm có phân trang, tìm kiếm và lọc
     * @param int $page Trang hiện tại
     * @param int $limit Số bản ghi mỗi trang
     * @param string $search Từ khóa tìm kiếm tên sản phẩm
     * @param array $filters Bộ lọc giá (ví dụ: ['price <' => 10000000])
     */
    public function list($page = 1, $limit = 10, $search = '', $filters = []) {
        // Sử dụng hàm paginate từ Model cơ sở
        // Liên kết với bảng 'category' (số ít) và 'brands' để lấy tên danh mục/thương hiệu
        return $this->paginate(
            $this->table,
            $page,
            $limit,
            $search,
            $filters,
            'name', // Cột tìm kiếm mặc định
            "main_t.*, c.name as category_name, b.name as brand_name",
            "LEFT JOIN category c ON main_t.category_id = c.id 
             LEFT JOIN brands b ON main_t.brand_id = b.id"
        );
    }

    /**
     * Lấy thông tin chi tiết một sản phẩm theo ID
     * @param int $id
     */
    public function show($id) {
        $sql = "SELECT * FROM {$this->table} WHERE id = ? AND deleted_at IS NULL LIMIT 1";
        return $this->query($sql, [$id])->fetch();
    }

    /**
     * Kiểm tra trùng tên sản phẩm (không tính các bản ghi đã xóa mềm)
     * @param string $name Tên cần kiểm tra
     * @param int|null $excludeId ID cần loại trừ khi cập nhật
     */
    public function exists($name, $excludeId = null) {
        return $this->checkExists($this->table, 'name', $name, $excludeId);
    }

    /**
     * Thêm sản phẩm mới
     * @param array $data Mảng chứa thông tin: name, price, image, category_id, brand_id
     */
    public function create($data) {
        $sql = "INSERT INTO {$this->table} (name, price, image, category_id, brand_id) 
                VALUES (:name, :price, :image, :category_id, :brand_id)";
        
        // Đảm bảo các tham số truyền vào query khớp với các placeholder trong SQL
        return $this->query($sql, [
            'name'        => $data['name'],
            'price'       => $data['price'],
            'image'       => $data['image'] ?? null,
            'category_id' => $data['category_id'] ?? null,
            'brand_id'    => $data['brand_id'] ?? null
        ]);
    }

    /**
     * Cập nhật thông tin sản phẩm
     * @param int $id ID của sản phẩm cần sửa
     * @param array $data Mảng chứa thông tin cập nhật
     */
    public function update($id, $data) {
        $sql = "UPDATE {$this->table} SET 
                name = :name, 
                price = :price, 
                image = :image, 
                category_id = :category_id, 
                brand_id = :brand_id 
                WHERE id = :id";
        
        // Gộp ID vào mảng dữ liệu để bind tham số :id
        $params = [
            'id'          => $id,
            'name'        => $data['name'],
            'price'       => $data['price'],
            'image'       => $data['image'] ?? null,
            'category_id' => $data['category_id'] ?? null,
            'brand_id'    => $data['brand_id'] ?? null
        ];

        return $this->query($sql, $params);
    }

    /**
     * Thực hiện xóa mềm sản phẩm (Soft Delete)
     * @param int $id
     */
    public function delete($id) {
        $sql = "UPDATE {$this->table} SET deleted_at = NOW() WHERE id = ?";
        return $this->query($sql, [$id]);
    }
}