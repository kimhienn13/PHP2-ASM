<?php

/**
 * Category Model xử lý dữ liệu cho bảng 'category'
 * Kế thừa các phương thức từ lớp Model cơ sở trong Canvas
 */
class Category extends Model {
    protected $table = 'category';

    /**
     * Lấy danh sách danh mục có phân trang và tìm kiếm
     */
    public function list($page = 1, $limit = 10, $search = '') {
        return $this->paginate(
            $this->table,
            $page,
            $limit,
            $search,
            [],
            'name'
        );
    }

    /**
     * Lấy thông tin chi tiết một danh mục
     */
    public function show($id) {
        $sql = "SELECT * FROM {$this->table} WHERE id = ? AND deleted_at IS NULL LIMIT 1";
        return $this->query($sql, [$id])->fetch();
    }

    /**
     * Kiểm tra trùng tên danh mục
     */
    public function isDuplicate($name, $excludeId = null) {
        return $this->checkExists($this->table, 'name', $name, $excludeId);
    }

    public function create($data) {
        $sql = "INSERT INTO {$this->table} (name, image) VALUES (:name, :image)";
        return $this->query($sql, [
            'name'  => $data['name'],
            'image' => $data['image'] ?? null
        ]);
    }

    public function update($id, $data) {
        $sql = "UPDATE {$this->table} SET name = :name, image = :image WHERE id = :id";
        return $this->query($sql, [
            'id'    => $id,
            'name'  => $data['name'],
            'image' => $data['image'] ?? null
        ]);
    }

    public function delete($id) {
        $sql = "UPDATE {$this->table} SET deleted_at = NOW() WHERE id = ?";
        return $this->query($sql, [$id]);
    }
}