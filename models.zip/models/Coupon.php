<?php

/**
 * Model Coupon xử lý các thao tác dữ liệu liên quan đến mã giảm giá
 */
class Coupon extends Model {
    protected $table = 'coupons';

    /**
     * Lấy danh sách mã giảm giá có phân trang và tìm kiếm
     */
    public function list($page = 1, $limit = 6, $search = '') {
        // Sử dụng hàm paginate từ Model cơ sở, tìm kiếm theo cột 'code'
        return $this->paginate($this->table, $page, $limit, $search, [], 'code');
    }

    /**
     * Kiểm tra mã code đã tồn tại chưa (phục vụ validation)
     */
    public function exists($code, $excludeId = null) {
        return $this->checkExists($this->table, 'code', $code, $excludeId);
    }

    /**
     * Tạo mới mã giảm giá
     */
    public function create($data) {
        $sql = "INSERT INTO {$this->table} (code, type, value, status, created_at) 
                VALUES (:code, :type, :value, :status, NOW())";
        
        return $this->query($sql, [
            'code'   => strtoupper($data['code']),
            'type'   => $data['type'],
            'value'  => $data['value'],
            'status' => $data['status']
        ]);
    }
}