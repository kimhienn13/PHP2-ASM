<?php

/**
 * User Model xử lý logic dữ liệu cho thành viên và xác thực
 */
class User extends Model {
    protected $table = 'users';

    /**
     * Lấy danh sách thành viên có phân trang và tìm kiếm
     * @param int $page Trang hiện tại
     * @param int $limit Số lượng bản ghi trên một trang
     * @param string $search Từ khóa tìm kiếm theo tên đầy đủ
     */
    public function list($page = 1, $limit = 10, $search = '') {
        // Sử dụng phương thức paginate từ Model cơ sở, tìm kiếm theo cột fullname
        return $this->paginate($this->table, $page, $limit, $search, [], 'fullname');
    }

    /**
     * Lấy thông tin chi tiết của một thành viên theo ID
     * @param int $id
     */
    public function show($id) {
        $sql = "SELECT * FROM {$this->table} WHERE id = ? AND deleted_at IS NULL LIMIT 1";
        return $this->query($sql, [$id])->fetch();
    }

    /**
     * Tìm kiếm thành viên theo địa chỉ email (phục vụ đăng nhập)
     * @param string $email
     */
    public function findByEmail($email) {
        $sql = "SELECT * FROM {$this->table} WHERE email = ? AND deleted_at IS NULL LIMIT 1";
        return $this->query($sql, [$email])->fetch();
    }

    /**
     * Kiểm tra sự tồn tại của email (trừ ID hiện tại nếu là cập nhật)
     * @param string $email
     * @param int|null $excludeId
     */
    public function exists($email, $excludeId = null) {
        return $this->checkExists($this->table, 'email', $email, $excludeId);
    }

    /**
     * Tạo mới một thành viên và mã hóa mật khẩu
     * @param array $data Dữ liệu bao gồm fullname, email, password
     */
    public function create($data) {
        $sql = "INSERT INTO {$this->table} (fullname, email, password, created_at, deleted_at) 
                VALUES (:fullname, :email, :password, NOW(), NULL)";
        
        // Mã hóa mật khẩu bảo mật bằng thuật toán BCRYPT
        $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT);

        return $this->query($sql, [
            'fullname' => $data['fullname'],
            'email'    => $data['email'],
            'password' => $hashedPassword
        ]);
    }

    /**
     * Cập nhật mật khẩu mới cho thành viên
     * @param string $email
     * @param string $newPassword
     */
    public function updatePassword($email, $newPassword) {
        $hashed = password_hash($newPassword, PASSWORD_BCRYPT);
        $sql = "UPDATE {$this->table} SET password = ? WHERE email = ?";
        return $this->query($sql, [$hashed, $email]);
    }
}