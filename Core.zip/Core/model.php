<?php

/**
 * Lớp Model cơ sở đã được nâng cấp để đọc cấu hình từ .env
 */
class Model {
    protected $db;

    public function __construct() {
        /**
         * Lấy thông tin cấu hình từ biến môi trường ($_ENV)
         * Các biến này được nạp từ file .env thông qua bootstrap.php
         */
        $host     = $_ENV['HOST'] ?? '127.0.0.1';
        $database = $_ENV['DATABASE'] ?? 'php-lop';
        $username = $_ENV['USERNAME'] ?? 'root';
        $password = $_ENV['PASSWORD'] ?? '';
        $charset  = 'utf8mb4';

        $dsn = "mysql:host=$host;dbname=$database;charset=$charset";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $this->db = new PDO($dsn, $username, $password, $options);
        } catch (\PDOException $e) {
            die("Kết nối Database thất bại: " . $e->getMessage());
        }
    }

    public function query($sql, $params = []) {
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function checkExists($table, $column, $value, $excludeId = null) {
        $sql = "SELECT COUNT(*) FROM $table WHERE $column = ? AND deleted_at IS NULL";
        $params = [$value];
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        return (int)$this->query($sql, $params)->fetchColumn() > 0;
    }

    public function paginate($table, $page = 1, $limit = 10, $search = '', $filters = [], $searchCol = 'name', $customSelect = '*', $customJoin = '') {
        $offset = ($page - 1) * $limit;
        $where = "WHERE main_t.deleted_at IS NULL";
        $params = [];

        if (!empty($search)) {
            $col = (strpos($searchCol, '.') === false) ? "main_t.$searchCol" : $searchCol;
            $where .= " AND $col LIKE :search";
            $params[':search'] = "%$search%";
        }

        foreach ($filters as $key => $filterData) {
            $parts = explode(' ', trim($key));
            $col = $parts[0];
            $operator = $parts[1] ?? '=';
            $value = is_array($filterData) ? ($filterData['value'] ?? null) : $filterData;

            if ($value !== '' && $value !== null) {
                $cleanParamName = str_replace(['.', ' ', '(', ')', '<', '>', '='], '_', $key);
                $paramKey = "f_" . $cleanParamName;
                $dbCol = (strpos($col, '.') === false) ? "main_t.$col" : $col;
                $where .= " AND $dbCol $operator :$paramKey";
                $params[":$paramKey"] = $value;
            }
        }

        try {
            $sql = "SELECT $customSelect FROM $table main_t $customJoin $where ORDER BY main_t.id DESC LIMIT :limit OFFSET :offset";
            $stmt = $this->db->prepare($sql);
            foreach ($params as $k => $v) { $stmt->bindValue($k, $v); }
            $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
            $stmt->execute();
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $countSql = "SELECT COUNT(*) FROM $table main_t $customJoin $where";
            $countStmt = $this->db->prepare($countSql);
            foreach ($params as $k => $v) { $countStmt->bindValue($k, $v); }
            $countStmt->execute();
            $total = (int)$countStmt->fetchColumn();

            return [
                'data' => $data,
                'total' => $total,
                'totalPages' => (int)ceil($total / $limit)
            ];
        } catch (PDOException $e) {
            return ['data' => [], 'total' => 0, 'totalPages' => 0];
        }
    }
}