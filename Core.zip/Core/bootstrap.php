<?php

// Định nghĩa các đường dẫn thư mục vật lý
define('BASE_PATH', dirname(__DIR__, 2));
define('APP_PATH', BASE_PATH . '/app');
define('VIEW_PATH', APP_PATH . '/views');
define('CONTROLLER_PATH', APP_PATH . '/controllers');
define('MODEL_PATH', APP_PATH . '/models');

/**
 * TỰ ĐỘNG XÁC ĐỊNH BASE_URL
 */
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$scriptName = $_SERVER['SCRIPT_NAME']; 
$baseDir = rtrim(dirname($scriptName), '/\\'); 

define('BASE_URL', $protocol . "://" . $host . $baseDir);

/**
 * Nạp Autoload của Vendor
 * QUAN TRỌNG: Thư mục 'vendor' thường nằm ở thư mục gốc (BASE_PATH)
 */
$vendorAutoload = BASE_PATH . '/vendor/autoload.php';

if (file_exists($vendorAutoload)) {
    require_once $vendorAutoload;
} else {
    /**
     * Nếu không tìm thấy, kiểm tra xem bạn có lỡ chạy composer trong thư mục /app không
     */
    $altVendor = APP_PATH . '/vendor/autoload.php';
    if (file_exists($altVendor)) {
        require_once $altVendor;
    } else {
        // Nếu vẫn không thấy, dừng chương trình và báo lỗi cụ thể
        die("Lỗi: Không tìm thấy thư mục 'vendor'. Bạn hãy mở terminal tại " . BASE_PATH . " và chạy lệnh: composer require vlucas/phpdotenv jenssegers/blade");
    }
}

// Nạp biến môi trường từ file .env ở thư mục gốc
if (class_exists(\Dotenv\Dotenv::class)) {
    $dotenv = \Dotenv\Dotenv::createImmutable(BASE_PATH);
    $dotenv->safeLoad();
}

// Tự động nạp Class (Core, Controller, Model)
spl_autoload_register(function (string $class): void {
    $paths = [
        APP_PATH . '/core/' . $class . '.php',
        APP_PATH . '/Core/' . $class . '.php', // Thêm dự phòng trường hợp viết hoa thư mục Core
        CONTROLLER_PATH . '/' . $class . '.php',
        MODEL_PATH . '/' . $class . '.php',
    ];

    foreach ($paths as $path) {
        if (file_exists($path)) {
            require_once $path;
            return;
        }
    }
});