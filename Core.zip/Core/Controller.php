<?php

use Jenssegers\Blade\Blade;

/**
 * Lớp Controller cơ sở đã được nâng cấp hỗ trợ Blade Engine
 */
class Controller
{
    /**
     * Hàm hiển thị giao diện sử dụng Blade Engine
     * @param string $path Đường dẫn view (ví dụ: 'user.index' thay vì 'user/index')
     * @param array $data Dữ liệu truyền xuống view
     */
    public function view($path, $data = [])
    {
        // Đường dẫn đến thư mục chứa các file .blade.php
        $viewPath = VIEW_PATH;
        // Đường dẫn đến thư mục lưu cache của Blade (Cần tạo thư mục này)
        $cachePath = BASE_PATH . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'cache';

        // Tự động tạo thư mục cache nếu chưa có
        if (!file_exists($cachePath)) {
            mkdir($cachePath, 0777, true);
        }

        // Khởi tạo Blade Engine
        $blade = new Blade($viewPath, $cachePath);

        /**
         * Render giao diện và xuất ra trình duyệt
         * Cú pháp gọi trong Controller: $this->view('product.index', $data);
         */
        echo $blade->make($path, $data)->render();
    }

    /**
     * Hàm khởi tạo và trả về đối tượng Model
     */
    public function model($name)
    {
        $class = ucfirst($name);
        if (!class_exists($class)) {
            throw new Error("Lỗi: Lớp Model '$class' không tồn tại.");
        }
        return new $class();
    }

    /**
     * Hàm chuyển hướng trang
     */
    public function redirect($path)
    {
        $target = BASE_URL . '/' . ltrim($path, '/');
        header("Location: $target");
        exit();
    }

    /**
     * Hiển thị lỗi 404
     */
    public function notfound($message): void
    {
        http_response_code(404);
        echo "<div style='text-align:center; margin-top:50px; font-family: sans-serif;'>";
        echo "<h1 style='color: red; font-size: 50px;'>404</h1>";
        echo "<h2>Không tìm thấy trang</h2>";
        echo "<p>" . htmlspecialchars($message) . "</p>";
        echo "<a href='" . BASE_URL . "/'>Quay lại trang chủ</a>";
        echo "</div>";
    }
}