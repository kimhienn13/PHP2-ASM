<!DOCTYPE html>

<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{{ $title ?? 'Đăng ký tài khoản' }}</title>
<!-- Bootstrap 5 & Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<style>
body {
background-color: #f0f2f5;
height: 100vh;
display: flex;
align-items: center;
justify-content: center;
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.auth-card {
width: 100%;
max-width: 450px;
border-radius: 20px;
border: none;
box-shadow: 0 15px 35px rgba(0,0,0,0.1);
overflow: hidden;
background: #fff;
}
.auth-header {
background: linear-gradient(135deg, #198754 0%, #157347 100%);
padding: 40px 20px;
text-align: center;
color: #fff;
}
.auth-header i {
font-size: 3rem;
margin-bottom: 10px;
}
.form-control {
border-radius: 10px;
padding: 12px 15px;
border: 1px solid #ddd;
}
.form-control:focus {
box-shadow: 0 0 0 0.25rem rgba(25, 135, 84, 0.15);
border-color: #198754;
}
.btn-register {
border-radius: 10px;
padding: 12px;
font-weight: bold;
text-transform: uppercase;
letter-spacing: 1px;
transition: all 0.3s;
}
.btn-register:hover {
transform: translateY(-2px);
box-shadow: 0 5px 15px rgba(25, 135, 84, 0.3);
}
.auth-links a {
color: #198754;
text-decoration: none;
font-weight: 500;
}
.auth-links a:hover {
text-decoration: underline;
}
.divider {
display: flex;
align-items: center;
text-align: center;
margin: 20px 0;
color: #888;
}
.divider::before, .divider::after {
content: '';
flex: 1;
border-bottom: 1px solid #eee;
}
.divider:not(:empty)::before { margin-right: .5em; }
.divider:not(:empty)::after { margin-left: .5em; }
</style>
</head>
<body>

<div class="auth-card shadow-lg">
<div class="auth-header">
<i class="bi bi-person-plus-fill"></i>
<h3 class="fw-bold mb-0">THAM GIA NGAY!</h3>
<p class="small opacity-75">Tạo tài khoản để bắt đầu trải nghiệm</p>
</div>

<div class="card-body p-4 p-md-5">
    <!-- Thông báo từ Session -->
    @if(isset($_SESSION['error']))
        <div class="alert alert-danger border-0 shadow-sm mb-4 small">
            <i class="bi bi-exclamation-circle-fill me-2"></i>
            {{ $_SESSION['error'] }}
            @php unset($_SESSION['error']) @endphp
        </div>
    @endif

    <form action="{{ BASE_URL }}/auth/postRegister" method="POST">
        <!-- Họ tên -->
        <div class="mb-3">
            <label class="form-label small fw-bold text-muted text-uppercase">Họ và Tên</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-person text-muted"></i></span>
                <input type="text" name="fullname" class="form-control border-start-0" placeholder="Nguyễn Văn A" required>
            </div>
        </div>

        <!-- Email -->
        <div class="mb-3">
            <label class="form-label small fw-bold text-muted text-uppercase">Địa chỉ Email</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope text-muted"></i></span>
                <input type="email" name="email" class="form-control border-start-0" placeholder="name@example.com" required>
            </div>
        </div>

        <!-- Mật khẩu -->
        <div class="mb-4">
            <label class="form-label small fw-bold text-muted text-uppercase">Mật khẩu</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-shield-lock text-muted"></i></span>
                <input type="password" name="password" class="form-control border-start-0" placeholder="••••••••" required minlength="6">
            </div>
            <div class="form-text mt-2 small">Mật khẩu phải có ít nhất 6 ký tự.</div>
        </div>

        <!-- Nút Đăng ký -->
        <button type="submit" class="btn btn-success w-100 btn-register shadow-sm mb-3">
            Đăng ký tài khoản
        </button>

        <div class="divider">HOẶC</div>

        <div class="text-center auth-links">
            <p class="small text-muted mb-0">Bạn đã có tài khoản?</p>
            <a href="{{ BASE_URL }}/auth/login">Đăng nhập tại đây</a>
        </div>
    </form>
</div>

<div class="card-footer bg-light border-0 py-3 text-center">
    <a href="{{ BASE_URL }}/" class="text-muted small text-decoration-none">
        <i class="bi bi-arrow-left me-1"></i> Quay lại trang chủ
    </a>
</div>


</div>

<!-- Bootstrap Bundle JS -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>