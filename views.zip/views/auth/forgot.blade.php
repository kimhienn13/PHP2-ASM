<!DOCTYPE html>

<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{{ $title ?? 'Khôi phục mật khẩu' }}</title>
<!-- Bootstrap 5 & Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<style>
body {
background-color: #f0f2f5;
height: 100vh;
display: flex;
align-items: center;
justify-content: center;
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.auth-card {
width: 100%;
max-width: 400px;
border-radius: 20px;
border: none;
box-shadow: 0 15px 35px rgba(0,0,0,0.1);
overflow: hidden;
background: #fff;
}
.auth-header {
background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
padding: 40px 20px;
text-align: center;
color: #212529;
}
.auth-header i {
font-size: 3rem;
margin-bottom: 10px;
}
.form-control {
border-radius: 10px;
padding: 12px 15px;
border: 1px solid #ddd;
}
.form-control:focus {
box-shadow: 0 0 0 0.25rem rgba(255, 193, 7, 0.15);
border-color: #ffc107;
}
.btn-forgot {
border-radius: 10px;
padding: 12px;
font-weight: bold;
text-transform: uppercase;
letter-spacing: 1px;
transition: all 0.3s;
color: #212529;
}
.btn-forgot:hover {
transform: translateY(-2px);
box-shadow: 0 5px 15px rgba(255, 193, 7, 0.3);
background-color: #e0a800;
}
.auth-links a {
color: #d39e00;
text-decoration: none;
font-weight: 500;
}
.auth-links a:hover {
text-decoration: underline;
}
.divider {
display: flex;
align-items: center;
text-align: center;
margin: 20px 0;
color: #888;
}
.divider::before, .divider::after {
content: '';
flex: 1;
border-bottom: 1px solid #eee;
}
.divider:not(:empty)::before { margin-right: .5em; }
.divider:not(:empty)::after { margin-left: .5em; }
</style>
</head>
<body>

<div class="auth-card shadow-lg">
<div class="auth-header">
<i class="bi bi-shield-lock-fill"></i>
<h3 class="fw-bold mb-0">QUÊN MẬT KHẨU?</h3>
<p class="small opacity-75">Nhập email để đặt lại mật khẩu mới</p>
</div>

<div class="card-body p-4 p-md-5">
    <!-- Thông báo từ Session -->
    @if(isset($_SESSION['error']))
        <div class="alert alert-danger border-0 shadow-sm mb-4 small">
            <i class="bi bi-exclamation-circle-fill me-2"></i>
            {{ $_SESSION['error'] }}
            @php unset($_SESSION['error']) @endphp
        </div>
    @endif

    @if(isset($_SESSION['success']))
        <div class="alert alert-success border-0 shadow-sm mb-4 small">
            <i class="bi bi-check-circle-fill me-2"></i>
            {{ $_SESSION['success'] }}
            @php unset($_SESSION['success']) @endphp
        </div>
    @endif

    <form action="{{ BASE_URL }}/auth/postForgot" method="POST">
        <!-- Email -->
        <div class="mb-3">
            <label class="form-label small fw-bold text-muted text-uppercase">Email đăng ký</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope text-muted"></i></span>
                <input type="email" name="email" class="form-control border-start-0" placeholder="name@example.com" required>
            </div>
        </div>

        <!-- Mật khẩu mới -->
        <div class="mb-4">
            <label class="form-label small fw-bold text-muted text-uppercase">Mật khẩu mới</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-key text-muted"></i></span>
                <input type="password" name="password" class="form-control border-start-0" placeholder="Nhập mật khẩu mới" required minlength="6">
            </div>
            <div class="form-text mt-2 small">Đặt mật khẩu mới mà bạn dễ ghi nhớ.</div>
        </div>

        <!-- Nút xác nhận -->
        <button type="submit" class="btn btn-warning w-100 btn-forgot shadow-sm mb-3">
            Đổi mật khẩu ngay
        </button>

        <div class="divider">HOẶC</div>

        <div class="text-center auth-links">
            <a href="{{ BASE_URL }}/auth/login" class="small">
                <i class="bi bi-arrow-left me-1"></i> Quay lại Đăng nhập
            </a>
        </div>
    </form>
</div>

<div class="card-footer bg-light border-0 py-3 text-center">
    <span class="small text-muted">Cần hỗ trợ? Liên hệ quản trị viên</span>
</div>


</div>

<!-- Bootstrap Bundle JS -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>