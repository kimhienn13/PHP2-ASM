<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'Quản lý Mã giảm giá' }}</title>
    <!-- Bootstrap 5 & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .navbar {
            border-bottom: 3px solid #0d6efd;
            margin-bottom: 30px;
        }

        .card {
            border-radius: 15px;
            border: none;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }

        #ajaxAlert {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 2000;
            display: none;
            min-width: 300px;
        }
    </style>
</head>

<body>

    <!-- Thông báo Popup -->
    <div id="ajaxAlert" class="alert alert-dismissible fade show shadow-lg" role="alert">
        <span id="ajaxAlertMsg"></span>
        <button type="button" class="btn-close" onclick="this.parentElement.style.display='none'"></button>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="{{ $baseUrl }}/">MVC Admin</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/product/index">Sản phẩm</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/category/index">Danh mục</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/brand/index">Thương hiệu</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/user/index">Thành viên</a></li>
                    <li class="nav-item"><a class="nav-link active" href="{{ $baseUrl }}/coupon/index">Coupon</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/cart/index">Giỏ hàng</a></li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ BASE_URL }}/auth/login">
                            <i class="bi bi-box-arrow-in-right me-1"></i>Đăng nhập
                        </a>
                    </li>
                    <li class="nav-item ms-lg-2">
                        <a class="nav-link btn btn-primary btn-sm px-3 text-white" href="{{ BASE_URL }}/auth/register">
                            Đăng ký
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0 fw-bold text-dark"><i class="bi bi-ticket-perforated text-primary me-2"></i>Quản lý Mã giảm giá</h2>
            <button class="btn btn-primary shadow-sm px-4" data-bs-toggle="modal" data-bs-target="#addCouponModal">
                <i class="bi bi-plus-lg me-1"></i>Thêm mã mới
            </button>
        </div>

        <div class="card shadow-sm border-0 rounded-3 overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th class="ps-4" width="80">STT</th>
                            <th>Mã Code</th>
                            <th>Loại</th>
                            <th>Giá trị giảm</th>
                            <th>Trạng thái</th>
                            <th class="text-end pe-4">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($coupons as $index => $c)
                        <tr>
                            <td class="ps-4 text-muted">{{ (($currentPage ?? 1) - 1) * 6 + $index + 1 }}</td>
                            <td><span class="badge bg-info-subtle text-info border px-3 py-2 fw-bold">{{ $c['code'] }}</span></td>
                            <td>{{ $c['type'] == 'percent' ? 'Phần trăm' : 'Cố định' }}</td>
                            <td class="fw-bold text-danger">{{ number_format($c['value']) }}{{ $c['type'] == 'percent' ? '%' : 'đ' }}</td>
                            <td>
                                @if($c['status'])
                                <span class="badge bg-success">Đang chạy</span>
                                @else
                                <span class="badge bg-secondary">Tạm dừng</span>
                                @endif
                            </td>
                            <td class="text-end pe-4">
                                <div class="btn-group">
                                    <button class="btn btn-sm btn-outline-warning btn-edit-coupon"
                                        data-bs-toggle="modal" data-bs-target="#editCouponModal"
                                        data-id="{{ $c['id'] }}" data-code="{{ $c['code'] }}"
                                        data-type="{{ $c['type'] }}" data-value="{{ $c['value'] }}" data-status="{{ $c['status'] }}">
                                        Sửa
                                    </button>
                                    <a href="{{ $baseUrl }}/coupon/destroy/{{ $c['id'] }}" class="btn btn-sm btn-outline-danger" onclick="return confirm('Xóa?')">Xóa</a>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="6" class="text-center p-5 text-muted">Trống</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    @include('coupon.them')
    @include('coupon.edit')

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const editModal = document.getElementById('editCouponModal');

            // Khắc phục lỗi 404 bằng cách nhận diện chính xác thư mục gốc /PHP2
            let BASE_URL = <?php echo json_encode($baseUrl ?? '/PHP2'); ?>;
            if (BASE_URL === '/') BASE_URL = '';

            function showAlert(message, type = 'success') {
                const box = document.getElementById('ajaxAlert');
                document.getElementById('ajaxAlertMsg').innerText = message;
                box.className = `alert alert-${type} alert-dismissible fade show shadow-lg`;
                box.style.display = 'block';
                setTimeout(() => box.style.display = 'none', 3000);
            }

            // 1. Hiện thông tin lên Modal
            if (editModal) {
                editModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget.closest('.btn-edit-coupon');
                    if (!button) return;
                    const data = button.dataset;

                    const form = document.getElementById('editCouponForm');
                    form.setAttribute('data-id', data.id);

                    document.getElementById('edit_code').value = data.code;
                    document.getElementById('edit_type').value = data.type;
                    document.getElementById('edit_value').value = data.value;
                    document.getElementById('edit_status').checked = (data.status == "1");
                });
            }

            // 2. Hàm gửi AJAX (Dùng chung cho cả Thêm và Sửa)
            async function setupForm(formId, apiPath, modalId) {
                const form = document.getElementById(formId);
                if (!form) return;

                form.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const id = this.getAttribute('data-id') || '';
                    const url = id ? `${BASE_URL}/${apiPath}/${id}` : `${BASE_URL}/${apiPath}`;

                    try {
                        const response = await fetch(url, {
                            method: 'POST',
                            body: new FormData(this)
                        });
                        const result = await response.json();

                        if (result.success) {
                            bootstrap.Modal.getInstance(document.getElementById(modalId)).hide();
                            showAlert(result.message);
                            setTimeout(() => window.location.reload(), 1000);
                        } else {
                            showAlert(result.message, 'danger');
                        }
                    } catch (err) {
                        showAlert('Lỗi kết nối. Hãy kiểm tra lại đường dẫn!', 'danger');
                    }
                });
            }

            // Kích hoạt AJAX cho Form Sửa
            setupForm('editCouponForm', 'coupon/update', 'editCouponModal');

            // Kích hoạt AJAX cho Form Thêm (Đảm bảo form trong them.blade.php có id="addCouponForm")
            const addForm = document.querySelector('#addCouponModal form');
            if (addForm) {
                addForm.id = 'addCouponForm';
                setupForm('addCouponForm', 'coupon/store', 'addCouponModal');
            }
        });
    </script>
</body>

</html>