<!-- Modal Sửa Mã Giảm Giá -->

<div class="modal fade" id="editCouponModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<!-- ID form "editCouponForm" để JS cập nhật thuộc tính action động -->
<form id="editCouponForm" action="" method="POST" class="modal-content border-0 shadow-lg" style="border-radius: 15px;">
<div class="modal-header bg-warning border-0" style="border-top-left-radius: 15px; border-top-right-radius: 15px;">
<h5 class="modal-title fw-bold text-dark">
<i class="bi bi-pencil-square me-2"></i>Cập Nhật Mã Giảm Giá
</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

        <div class="modal-body p-4">
            <!-- Mã giảm giá (Code) -->
            <div class="mb-4">
                <label class="form-label fw-bold">Mã giảm giá (Code)</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="bi bi-tag-fill text-warning"></i></span>
                    <!-- Mã code thường không cho phép sửa để đảm bảo tính toàn vẹn của lịch sử đơn hàng -->
                    <input type="text" id="edit_code" name="code" class="form-control border-start-0 px-3 py-2 text-uppercase fw-bold bg-light" readonly>
                </div>
                <div class="form-text mt-1 small text-muted italic">Mã giảm giá không được phép thay đổi.</div>
            </div>

            <!-- Loại hình giảm giá (Type) -->
            <div class="mb-4">
                <label class="form-label fw-bold">Loại hình giảm giá</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="bi bi-layers-half text-warning"></i></span>
                    <select id="edit_type" name="type" class="form-select border-start-0 px-3 py-2" required>
                        <option value="percent">Giảm theo phần trăm (%)</option>
                        <option value="fixed">Giảm số tiền cố định (đ)</option>
                    </select>
                </div>
            </div>

            <!-- Giá trị giảm (Value) -->
            <div class="mb-4">
                <label class="form-label fw-bold">Giá trị giảm</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="bi bi-cash-coin text-warning"></i></span>
                    <input type="number" id="edit_value" name="value" class="form-control border-start-0 px-3 py-2" placeholder="Nhập số..." required min="1">
                </div>
            </div>

            <!-- Trạng thái kích hoạt (Status) -->
            <div class="form-check form-switch mt-2">
                <input class="form-check-input" type="checkbox" name="status" value="1" id="edit_status">
                <label class="form-check-label fw-bold" for="edit_status">Đang kích hoạt mã này</label>
            </div>
        </div>

        <div class="modal-footer border-0 p-4 pt-0">
            <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Hủy bỏ</button>
            <button type="submit" class="btn btn-warning px-4 shadow-sm fw-bold text-dark">
                <i class="bi bi-check-lg me-2"></i>Lưu thay đổi
            </button>
        </div>
    </form>
</div>


</div>