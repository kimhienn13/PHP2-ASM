<div class="modal fade" id="addCouponModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <!-- Form gửi dữ liệu đến CouponController@store -->
        <form action="{{ $baseUrl }}/coupon/store" method="POST" class="modal-content border-0 shadow-lg" style="border-radius: 15px;">
            <div class="modal-header bg-primary text-white border-0" style="border-top-left-radius: 15px; border-top-right-radius: 15px;">
                <h5 class="modal-title fw-bold">
                    <i class="bi bi-plus-circle me-2"></i>Thêm Mã Giảm Giá Mới
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">
                <!-- Mã giảm giá (Code) -->
                <div class="mb-4">
                    <label for="coupon_code" class="form-label fw-bold">Mã giảm giá (Code)</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-tag-fill text-primary"></i></span>
                        <input type="text" id="coupon_code" name="code" class="form-control border-start-0 px-3 py-2 text-uppercase" 
                               placeholder="VÍ DỤ: GIAM20, TET2026..." required autocomplete="off">
                    </div>
                    <div class="form-text mt-1 text-muted small">Nên viết hoa, không dấu và không có khoảng cách.</div>
                </div>

                <!-- Loại hình giảm giá (Type) -->
                <div class="mb-4">
                    <label for="coupon_type" class="form-label fw-bold">Loại hình giảm giá</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-layers-half text-primary"></i></span>
                        <select id="coupon_type" name="type" class="form-select border-start-0 px-3 py-2" required>
                            <option value="percent">Giảm theo phần trăm (%)</option>
                            <option value="fixed">Giảm số tiền cố định (đ)</option>
                        </select>
                    </div>
                </div>

                <!-- Giá trị giảm (Value) -->
                <div class="mb-4">
                    <label for="coupon_value" class="form-label fw-bold">Giá trị giảm</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-cash-coin text-primary"></i></span>
                        <input type="number" id="coupon_value" name="value" class="form-control border-start-0 px-3 py-2" 
                               placeholder="Nhập số tiền hoặc %" required min="1">
                    </div>
                </div>

                <!-- Trạng thái kích hoạt (Status) -->
                <div class="form-check form-switch mt-2">
                    <input class="form-check-input" type="checkbox" name="status" value="1" checked id="statusAdd">
                    <label class="form-check-label fw-bold" for="statusAdd">Kích hoạt mã giảm giá này ngay</label>
                </div>
            </div>

            <div class="modal-footer border-0 p-4 pt-0">
                <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Hủy bỏ</button>
                <button type="submit" class="btn btn-primary px-4 shadow-sm fw-bold text-white">
                    <i class="bi bi-save me-2"></i>Lưu mã coupon
                </button>
            </div>
        </form>
    </div>
</div>