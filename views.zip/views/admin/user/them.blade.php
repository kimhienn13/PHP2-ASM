<div class="modal fade" id="addUserModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<form action="<?= BASE_URL ?>/user/store" method="POST" class="modal-content shadow-lg border-0" style="border-radius: 15px;">
<div class="modal-header bg-primary text-white border-0" style="border-top-left-radius: 15px; border-top-right-radius: 15px;">
<h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Thêm Thành Viên Mới</h5>
<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body p-4">
<div class="mb-3">
<label class="form-label fw-bold">Họ và Tên</label>
<input type="text" name="fullname" class="form-control" placeholder="Nguyễn Văn A" required>
</div>
<div class="mb-3">
<label class="form-label fw-bold">Email</label>
<input type="email" name="email" class="form-control" placeholder="name@example.com" required>
</div>
<div class="mb-3">
<label class="form-label fw-bold">Mật khẩu</label>
<input type="password" name="password" class="form-control" placeholder="Tối thiểu 6 ký tự" required>
</div>
</div>
<div class="modal-footer border-0 p-4 pt-0">
<button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Hủy</button>
<button type="submit" class="btn btn-primary px-4 shadow-sm">Lưu ngay</button>
</div>
</form>
</div>
</div>