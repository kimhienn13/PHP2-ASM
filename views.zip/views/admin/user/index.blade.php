<!DOCTYPE html>

<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'Quản lý Thành viên' }}</title>
    <!-- Nhúng CSS từ CDN trực tiếp -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        .pagination .page-link {
            color: #333;
        }

        .pagination .page-item.active .page-link {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }

        .table-hover tbody tr:hover {
            background-color: #f8f9fa;
        }

        .navbar {
            border-bottom: 3px solid #0d6efd;
        }

        .modal-content {
            border-radius: 15px;
            border: none;
        }
    </style>
</head>

<body class="bg-light">

    <!-- Thanh điều hướng -->

    @include('admin.header')

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0 text-dark fw-bold uppercase">
        <i class="bi bi-box-seam text-primary me-2"></i>Quản lý Sản phẩm
    </h2>
    <a href="{{ BASE_URL }}/adminproduct/create" class="btn btn-primary shadow-sm px-4 rounded-pill fw-bold">
        <i class="bi bi-plus-lg me-1"></i>Thêm sản phẩm mới
    </a>
</div>

<!-- Thanh công cụ: Tìm kiếm & Lọc -->
<div class="card p-3 mb-4 shadow-sm border-0 rounded-3">
    <form action="{{ BASE_URL }}/adminproduct/index" method="GET" class="row g-2">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
                <input type="text" name="search" class="form-control border-start-0 shadow-none"
                    placeholder="Tìm tên sản phẩm..." value="{{ $search ?? '' }}">
            </div>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-dark w-100 fw-bold">Tìm kiếm</button>
        </div>
        @if(!empty($search))
        <div class="col-md-2">
            <a href="{{ BASE_URL }}/adminproduct/index" class="btn btn-outline-secondary w-100">Xóa tìm</a>
        </div>
        @endif
    </form>
</div>

<!-- Bảng danh sách sản phẩm -->
<div class="card shadow-sm border-0 rounded-4 overflow-hidden">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-dark border-0">
                <tr>
                    <th class="ps-4 py-3" width="80">STT</th>
                    <th width="100">Ảnh</th>
                    <th>Tên sản phẩm</th>
                    <th>Danh mục</th>
                    <th>Giá bán</th>
                    <th class="text-end pe-4">Thao tác</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($products as $index => $p)
                <tr>
                    <td class="ps-4 text-muted">{{ ($currentPage - 1) * 10 + $index + 1 }}</td>
                    <td>
                        <img src="{{ BASE_URL }}/public/uploads/products/{{ $p['image'] ?? 'default.jpg' }}" 
                             class="rounded border shadow-sm" width="50" height="50" style="object-fit: cover;">
                    </td>
                    <td>
                        <div class="fw-bold text-dark">{{ $p['name'] }}</div>
                        <div class="text-muted small">ID: #{{ $p['id'] }}</div>
                    </td>
                    <td>
                        <span class="badge bg-light text-dark border rounded-pill px-3 font-normal">
                            {{ $p['category_name'] ?? 'Chưa phân loại' }}
                        </span>
                    </td>
                    <td>
                        <span class="fw-bold text-danger">{{ number_format($p['price']) }}đ</span>
                    </td>
                    <td class="text-end pe-4">
                        <div class="btn-group">
                            <a href="{{ BASE_URL }}/adminproduct/edit/{{ $p['id'] }}" class="btn btn-sm btn-outline-primary border-0">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            <a href="{{ BASE_URL }}/adminproduct/destroy/{{ $p['id'] }}"
                               class="btn btn-sm btn-outline-danger border-0"
                               onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="text-center p-5 text-muted italic">Hiện chưa có sản phẩm nào trong kho.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<!-- Phân trang -->
@if (isset($totalPages) && $totalPages > 1)
<nav class="mt-4">
    <ul class="pagination justify-content-center shadow-sm">
        @for ($i = 1; $i <= $totalPages; $i++)
            <li class="page-item {{ ($i == ($currentPage ?? 1)) ? 'active' : '' }}">
                <a class="page-link" href="{{ BASE_URL }}/adminproduct/index?page={{ $i }}&search={{ urlencode($search ?? '') }}">{{ $i }}</a>
            </li>
        @endfor
    </ul>
</nav>
@endif

@include('admin.footer')

</html>