<div class="modal fade" id="editUserModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<form id="editUserForm" action="" method="POST" class="modal-content shadow-lg border-0" style="border-radius: 15px;">
<div class="modal-header bg-warning text-dark border-0" style="border-top-left-radius: 15px; border-top-right-radius: 15px;">
<h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i>Cập Nhật Thành Viên</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body p-4">
<div class="mb-3">
<label class="form-label fw-bold">Họ và Tên</label>
<input type="text" name="fullname" id="edit_fullname" class="form-control" required>
</div>
<div class="mb-3">
<label class="form-label fw-bold">Email</label>
<input type="email" name="email" id="edit_email" class="form-control" required>
</div>
<div class="alert alert-info py-2 small border-0 shadow-sm">
<i class="bi bi-info-circle me-1"></i> Mật khẩu sẽ được giữ nguyên nếu không cập nhật trong logic backend.
</div>
</div>
<div class="modal-footer border-0 p-4 pt-0">
<button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Hủy</button>
<button type="submit" class="btn btn-warning px-4 shadow-sm fw-bold">Lưu thay đổi</button>
</div>
</form>
</div>
</div>