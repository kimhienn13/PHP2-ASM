<div class="modal fade" id="editProductModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-lg">
<!-- Form ID editProductForm được JavaScript sử dụng để thay đổi thuộc tính action -->
<form id="editProductForm" action="" method="POST" enctype="multipart/form-data" class="modal-content shadow-lg border-0">
<div class="modal-header bg-warning text-dark border-0">
<h5 class="modal-title fw-bold">
<i class="bi bi-pencil-square me-2"></i>Cập Nhật Sản Phẩm
</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

        <div class="modal-body p-4">
            <!-- Tên sản phẩm và Giá -->
            <div class="row mb-3">
                <div class="col-md-8">
                    <label class="form-label fw-bold">Tên sản phẩm</label>
                    <input type="text" name="name" id="edit_name" class="form-control px-3 py-2" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">Giá tiền (VNĐ)</label>
                    <input type="number" name="price" id="edit_price" class="form-control px-3 py-2" min="0" required>
                </div>
            </div>

            <!-- Danh mục và Thương hiệu -->
            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold">Danh mục</label>
                    <select name="category_id" id="edit_category_id" class="form-select px-3 py-2" required>
                        <?php if(!empty($all_categories)): ?>
                            <?php foreach ($all_categories as $c): ?>
                                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold">Thương hiệu</label>
                    <select name="brand_id" id="edit_brand_id" class="form-select px-3 py-2" required>
                        <?php if(!empty($all_brands)): ?>
                            <?php foreach ($all_brands as $b): ?>
                                <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>

            <!-- Xem trước ảnh và Chọn ảnh mới -->
            <div class="row align-items-center">
                <div class="col-md-3 text-center">
                    <div class="mb-2 small text-muted">Ảnh hiện tại</div>
                    <!-- ID edit_img_preview được JS sử dụng để thay đổi thuộc tính src -->
                    <img id="edit_img_preview" src="" class="product-img border shadow-sm w-100" style="max-width: 120px; height: 120px; object-fit: cover; border-radius: 10px;">
                </div>
                <div class="col-md-9">
                    <label class="form-label fw-bold">Thay đổi hình ảnh (không chọn nếu muốn giữ nguyên)</label>
                    <input type="file" name="image" class="form-control px-3 py-2" accept="image/*">
                    <div class="form-text mt-2 text-muted">
                        <i class="bi bi-info-circle me-1"></i> Để trống nếu bạn không muốn thay đổi ảnh sản phẩm.
                    </div>
                </div>
            </div>
        </div>

        <div class="modal-footer border-0 p-4 pt-0">
            <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Hủy bỏ</button>
            <button type="submit" class="btn btn-warning px-4 shadow-sm fw-bold">
                Cập nhật ngay
            </button>
        </div>
    </form>
</div>


</div>