<div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-lg">
<form action="<?= BASE_URL ?>/product/store" method="POST" enctype="multipart/form-data" class="modal-content shadow-lg border-0">
<div class="modal-header bg-primary text-white border-0">
<h5 class="modal-title fw-bold">
<i class="bi bi-plus-circle me-2"></i>Thêm Sản Phẩm Mới
</h5>
<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

        <div class="modal-body p-4">
            <div class="row mb-3">
                <div class="col-md-8">
                    <label class="form-label fw-bold">Tên sản phẩm</label>
                    <input type="text" name="name" class="form-control" placeholder="Nhập tên sản phẩm..." required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">Giá tiền (VNĐ)</label>
                    <input type="number" name="price" class="form-control" min="0" placeholder="Ví dụ: 500000" required>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold">Danh mục</label>
                    <select name="category_id" class="form-select" required>
                        <option value="">-- Chọn danh mục --</option>
                        <?php if(!empty($all_categories)): ?>
                            <?php foreach ($all_categories as $c): ?>
                                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold">Thương hiệu</label>
                    <select name="brand_id" class="form-select" required>
                        <option value="">-- Chọn thương hiệu --</option>
                        <?php if(!empty($all_brands)): ?>
                            <?php foreach ($all_brands as $b): ?>
                                <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>

            <div class="mb-0">
                <label class="form-label fw-bold">Hình ảnh sản phẩm</label>
                <input type="file" name="image" class="form-control" accept="image/*">
                <div class="form-text mt-2 text-muted">
                    <i class="bi bi-info-circle me-1"></i> Định dạng hỗ trợ: JPG, PNG, WebP. Tối đa 2MB.
                </div>
            </div>
        </div>

        <div class="modal-footer border-0 p-4 pt-0">
            <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Hủy bỏ</button>
            <button type="submit" class="btn btn-primary px-4 shadow-sm fw-bold">
                Lưu sản phẩm
            </button>
        </div>
    </form>
</div>


</div>