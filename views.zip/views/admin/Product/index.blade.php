<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'Quản lý Sản phẩm' }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        .pagination .page-link {
            color: #333;
        }

        .pagination .page-item.active .page-link {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }

        .table-hover tbody tr:hover {
            background-color: #f8f9fa;
        }

        .navbar {
            border-bottom: 3px solid #0d6efd;
        }

        .product-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid #dee2e6;
            background: white;
        }

        .modal-content {
            border-radius: 15px;
            border: none;
        }
    </style>
</head>

<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4 shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="{{ BASE_URL }}/">MVC Admin</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link active" href="{{ BASE_URL }}/product/index">Sản phẩm</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/category/index">Danh mục</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/brand/index">Thương hiệu</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/user/index">Thành viên</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/coupon/index">Coupon</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/cart/index">Giỏ hàng</a></li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ BASE_URL }}/auth/login">
                            <i class="bi bi-box-arrow-in-right me-1"></i>Đăng nhập
                        </a>
                    </li>
                    <li class="nav-item ms-lg-2">
                        <a class="nav-link btn btn-primary btn-sm px-3 text-white" href="{{ BASE_URL }}/auth/register">
                            Đăng ký
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        {{-- Thông báo lỗi/thành công --}}
        @if(isset($_GET['error']))
        <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0 mb-4 rounded-3" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            @switch($_GET['error'])
            @case('duplicate') Lỗi: Tên sản phẩm đã tồn tại! @break
            @case('negative_price') Lỗi: Giá tiền không được nhỏ hơn 0! @break
            @case('invalid_data') Lỗi: Vui lòng nhập đầy đủ thông tin! @break
            @default Đã xảy ra lỗi hệ thống!
            @endswitch
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        @endif

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0 fw-bold"><i class="bi bi-box-seam text-primary me-2"></i>Quản lý Sản phẩm</h2>
            <button class="btn btn-primary shadow-sm px-4" data-bs-toggle="modal" data-bs-target="#addProductModal">
                <i class="bi bi-plus-lg me-1"></i>Thêm sản phẩm mới
            </button>
        </div>

        <!-- Thanh Tìm kiếm -->
        <div class="card p-3 mb-4 shadow-sm border-0 rounded-3">
            <form action="{{ BASE_URL }}/product/index" method="GET" class="row g-2">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-search"></i></span>
                        <input type="text" name="search" class="form-control border-start-0"
                            placeholder="Tìm tên sản phẩm..." value="{{ $search ?? '' }}">
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-secondary w-100">Tìm kiếm</button>
                </div>
                @if(!empty($search))
                <div class="col-md-2">
                    <a href="{{ BASE_URL }}/product/index" class="btn btn-outline-secondary w-100">Xóa tìm</a>
                </div>
                @endif
            </form>
        </div>

        <!-- Bảng Sản phẩm -->
        <div class="card shadow-sm border-0 rounded-3 overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th class="ps-3" width="100">Ảnh</th>
                            <th>Tên sản phẩm</th>
                            <th>Giá tiền</th>
                            <th>Danh mục</th>
                            <th class="text-end pe-3">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($products as $p)
                        <tr>
                            <td class="ps-3">
                                <img src="{{ !empty($p['image']) ? BASE_URL . '/public/uploads/products/' . $p['image'] : 'https://placehold.co/60x60?text=No+Image' }}" class="product-img" alt="product">
                            </td>
                            <td class="fw-bold text-dark">{{ $p['name'] }}</td>
                            <td class="text-danger fw-bold">{{ number_format($p['price'], 0, ',', '.') }}đ</td>
                            <td><span class="badge bg-info text-dark">{{ $p['category_name'] ?? 'Chưa phân loại' }}</span></td>
                            <td class="text-end pe-3">
                                <div class="btn-group shadow-sm">
                                    <button class="btn btn-sm btn-outline-warning btn-edit-product"
                                        data-bs-toggle="modal" data-bs-target="#editProductModal"
                                        data-id="{{ $p['id'] }}"
                                        data-name="{{ htmlspecialchars($p['name']) }}"
                                        data-price="{{ $p['price'] }}"
                                        data-category="{{ $p['category_id'] }}"
                                        data-brand="{{ $p['brand_id'] }}"
                                        data-image="{{ $p['image'] }}">
                                        <i class="bi bi-pencil-square"></i> Sửa
                                    </button>
                                    <a href="{{ BASE_URL }}/product/destroy/{{ $p['id'] }}" class="btn btn-sm btn-outline-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')">
                                        <i class="bi bi-trash"></i> Xóa
                                    </a>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="text-center p-5 text-muted">Danh sách sản phẩm trống.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Thanh Phân trang -->
        @if (isset($totalPages) && $totalPages > 1)
        <nav class="mt-4">
            <ul class="pagination justify-content-center shadow-sm">
                @for ($i = 1; $i <= $totalPages; $i++)
                    <li class="page-item {{ ($i == ($currentPage ?? 1)) ? 'active' : '' }}">
                    <a class="page-link" href="{{ BASE_URL }}/product/index?page={{ $i }}&search={{ urlencode($search ?? '') }}">{{ $i }}</a>
                    </li>
                    @endfor
            </ul>
        </nav>
        @endif
    </div>

    {{-- Nhúng Modals --}}
    @include('product.them')
    @include('product.edit')

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const editButtons = document.querySelectorAll('.btn-edit-product');
            const editForm = document.getElementById('editProductForm');
            const imgPreview = document.getElementById('edit_img_preview');

            editButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // Lấy dữ liệu từ các thuộc tính data-
                    const id = this.dataset.id;
                    const name = this.dataset.name;
                    const price = this.dataset.price;
                    const catId = this.dataset.category;
                    const brandId = this.dataset.brand;
                    const img = this.dataset.image;

                    if (editForm) {
                        // Cập nhật action động cho form bằng hằng số BASE_URL
                        editForm.action = '{{ BASE_URL }}/product/update/' + id;

                        // Điền thông tin vào các ô nhập liệu
                        const nameInput = document.getElementById('edit_name');
                        const priceInput = document.getElementById('edit_price');
                        const catSelect = document.getElementById('edit_category_id');
                        const brandSelect = document.getElementById('edit_brand_id');

                        if (nameInput) nameInput.value = name;
                        if (priceInput) priceInput.value = price;
                        if (catSelect) catSelect.value = catId;
                        if (brandSelect) brandSelect.value = brandId;

                        // Cập nhật ảnh xem trước bằng hằng số BASE_URL
                        if (imgPreview) {
                            imgPreview.src = (img && img !== '') ? '{{ BASE_URL }}/public/uploads/products/' + img : 'https://placehold.co/120x120?text=No+Image';
                        }
                    }
                });
            });
        });
    </script>
</body>

</html>