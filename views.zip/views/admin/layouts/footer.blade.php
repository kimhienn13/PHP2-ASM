</div> <!-- Kết thúc container từ Header -->

<footer class="bg-white border-top py-4 mt-auto">
    <div class="container text-center">
        <p class="text-muted mb-0 small">
            <strong>TechMart Admin System</strong> &copy; 2026. Tất cả quyền được bảo lưu.
        </p>
    </div>
</footer>

<!-- JS: Bootstrap 5 Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>