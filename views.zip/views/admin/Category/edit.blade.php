<!-- Modal Sửa Danh mục -->

<div class="modal fade" id="editCategoryModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<!-- ID form "editCategoryForm" được JS dùng để thay đổi thuộc tính action động -->
<form id="editCategoryForm" action="" method="POST" enctype="multipart/form-data" class="modal-content shadow-lg border-0" style="border-radius: 15px;">
<div class="modal-header bg-warning text-dark border-0" style="border-top-left-radius: 15px; border-top-right-radius: 15px;">
<h5 class="modal-title fw-bold">
<i class="bi bi-pencil-square me-2"></i>Cập Nhật Danh Mục
</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

        <div class="modal-body p-4">
            <!-- Tên danh mục -->
            <div class="mb-4">
                <label class="form-label fw-bold">Tên danh mục</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="bi bi-tag"></i></span>
                    <!-- ID "edit_name" để JS đổ dữ liệu vào -->
                    <input type="text" name="name" id="edit_name" class="form-control border-start-0 px-3 py-2" required>
                </div>
            </div>

            <!-- Hiển thị ảnh cũ -->
            <div class="mb-4 text-center p-3 bg-light rounded-3 border border-dashed">
                <p class="mb-2 fw-bold small text-muted text-uppercase">Ảnh hiện tại</p>
                <!-- ID "edit_img_preview" để JS cập nhật đường dẫn ảnh -->
                <img id="edit_img_preview" src="" class="category-img shadow-sm" style="width: 100px; height: 100px; object-fit: cover; border-radius: 10px;" alt="Preview">
            </div>

            <!-- Chọn ảnh mới -->
            <div class="mb-0">
                <label class="form-label fw-bold">Thay đổi ảnh mới (Nếu có)</label>
                <input type="file" name="image" class="form-control px-3 py-2" accept="image/*">
                <div class="form-text mt-2 text-muted italic">
                    <i class="bi bi-info-circle me-1"></i> Để trống nếu bạn muốn giữ nguyên ảnh cũ.
                </div>
            </div>
        </div>

        <div class="modal-footer border-0 p-4 pt-0">
            <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Hủy bỏ</button>
            <button type="submit" class="btn btn-warning px-4 shadow-sm fw-bold text-dark">
                <i class="bi bi-check-lg me-2"></i>Cập nhật ngay
            </button>
        </div>
    </form>
</div>


</div>