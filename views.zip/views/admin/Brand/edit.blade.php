<!-- Modal Sửa Thương Hiệu -->

<div class="modal fade" id="editBrandModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<!-- ID form "editBrandForm" được JavaScript sử dụng để thay đổi thuộc tính action động -->
<form id="editBrandForm" action="" method="POST" enctype="multipart/form-data" class="modal-content shadow-lg border-0" style="border-radius: 15px;">
<div class="modal-header bg-warning text-dark border-0" style="border-top-left-radius: 15px; border-top-right-radius: 15px;">
<h5 class="modal-title fw-bold">
<i class="bi bi-pencil-square me-2"></i>Cập Nhật Thương Hiệu
</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

        <div class="modal-body p-4">
            <!-- Tên thương hiệu -->
            <div class="mb-3">
                <label class="form-label fw-bold">Tên thương hiệu</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="bi bi-award"></i></span>
                    <!-- ID "edit_name" để JavaScript đổ dữ liệu vào -->
                    <input type="text" name="name" id="edit_name" class="form-control border-start-0 px-3 py-2" required>
                </div>
            </div>

            <!-- Mô tả thương hiệu -->
            <div class="mb-3">
                <label class="form-label fw-bold">Mô tả</label>
                <!-- ID "edit_description" để JavaScript đổ dữ liệu vào -->
                <textarea name="description" id="edit_description" class="form-control px-3 py-2" rows="3" placeholder="Nhập mô tả thương hiệu..."></textarea>
            </div>

            <!-- Xem trước logo và Chọn logo mới -->
            <div class="row align-items-center mb-0">
                <div class="col-md-3 text-center">
                    <p class="mb-1 small fw-bold text-muted">Logo cũ</p>
                    <!-- ID "edit_img_preview" để JavaScript cập nhật đường dẫn ảnh -->
                    <img id="edit_img_preview" src="" class="brand-img border shadow-sm w-100" style="height: 70px; object-fit: contain; background: white; border-radius: 8px;">
                </div>
                <div class="col-md-9">
                    <label class="form-label fw-bold">Thay đổi logo (Nếu có)</label>
                    <input type="file" name="image" class="form-control px-3 py-2" accept="image/*">
                    <div class="form-text mt-2 text-muted italic">
                        <i class="bi bi-info-circle me-1"></i> Để trống nếu bạn muốn giữ nguyên logo cũ.
                    </div>
                </div>
            </div>
        </div>

        <div class="modal-footer border-0 p-4 pt-0">
            <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Hủy bỏ</button>
            <button type="submit" class="btn btn-warning px-4 shadow-sm fw-bold text-dark">
                <i class="bi bi-check-lg me-2"></i>Cập nhật ngay
            </button>
        </div>
    </form>
</div>


</div>