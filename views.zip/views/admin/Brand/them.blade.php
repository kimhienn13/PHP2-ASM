<!-- Modal Thêm Thương Hiệu -->

<div class="modal fade" id="addBrandModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<form action="<?= BASE_URL ?>/brand/store" method="POST" enctype="multipart/form-data" class="modal-content shadow-lg border-0" style="border-radius: 15px;">
<div class="modal-header bg-primary text-white border-0" style="border-top-left-radius: 15px; border-top-right-radius: 15px;">
<h5 class="modal-title fw-bold">
<i class="bi bi-plus-circle me-2"></i>Thêm Thương Hiệu Mới
</h5>
<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

        <div class="modal-body p-4">
            <!-- Tên thương hiệu -->
            <div class="mb-3">
                <label class="form-label fw-bold">Tên thương hiệu</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="bi bi-award"></i></span>
                    <input type="text" name="name" class="form-control border-start-0 px-3 py-2" placeholder="Ví dụ: Apple, Samsung, Sony..." required>
                </div>
            </div>

            <!-- Mô tả thương hiệu -->
            <div class="mb-3">
                <label class="form-label fw-bold">Mô tả</label>
                <textarea name="description" class="form-control px-3 py-2" rows="3" placeholder="Nhập mô tả ngắn gọn về thương hiệu..."></textarea>
            </div>

            <!-- Logo thương hiệu -->
            <div class="mb-0">
                <label class="form-label fw-bold">Logo thương hiệu</label>
                <input type="file" name="image" class="form-control px-3 py-2" accept="image/*">
                <div class="form-text mt-2 text-muted italic">
                    <i class="bi bi-info-circle me-1"></i> Định dạng: JPG, PNG, WebP. Dung lượng tối đa 2MB.
                </div>
            </div>
        </div>

        <div class="modal-footer border-0 p-4 pt-0">
            <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Hủy bỏ</button>
            <button type="submit" class="btn btn-primary px-4 shadow-sm fw-bold">
                <i class="bi bi-save me-2"></i>Lưu thương hiệu
            </button>
        </div>
    </form>
</div>


</div>