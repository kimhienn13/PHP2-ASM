<!DOCTYPE html>

<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'Giỏ hàng của bạn' }}</title>
    <!-- Bootstrap 5 & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .navbar {
            border-bottom: 3px solid #0d6efd;
            margin-bottom: 30px;
        }

        .card {
            border-radius: 15px;
            border: none;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }

        .product-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid #dee2e6;
        }

        .btn-qty {
            width: 35px;
            height: 35px;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .summary-total {
            border-top: 1px solid #dee2e6;
            padding-top: 15px;
            margin-top: 15px;
            font-weight: bold;
            font-size: 1.2rem;
        }
    </style>
</head>

<body>

    <!-- Thanh điều hướng -->

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="{{ BASE_URL }}/">MVC SHOP</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/product/index">Sản phẩm</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/category/index">Danh mục</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/brand/index">Thương hiệu</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/user/index">Thành viên</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ BASE_URL }}/coupon/index">Coupon</a></li>
                    <li class="nav-item"><a class="nav-link active" href="{{ BASE_URL }}/cart/index">Giỏ hàng</a></li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ BASE_URL }}/auth/login">
                            <i class="bi bi-box-arrow-in-right me-1"></i>Đăng nhập
                        </a>
                    </li>
                    <li class="nav-item ms-lg-2">
                        <a class="nav-link btn btn-primary btn-sm px-3 text-white" href="{{ BASE_URL }}/auth/register">
                            Đăng ký
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <!-- Danh sách sản phẩm trong giỏ -->
            <div class="col-lg-8">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-white py-3">
                        <h5 class="mb-0 fw-bold"><i class="bi bi-cart3 me-2 text-primary"></i>GIỎ HÀNG ({{ count($cart) }} sản phẩm)</h5>
                    </div>
                    <div class="card-body p-0">
                        @if(empty($cart))
                        <div class="text-center py-5">
                            <i class="bi bi-cart-x display-1 text-muted"></i>
                            <h4 class="mt-3 text-muted">Giỏ hàng của bạn đang trống</h4>
                            <a href="{{ BASE_URL }}/product/index" class="btn btn-primary mt-3 px-4 shadow-sm">Mua sắm ngay</a>
                        </div>
                        @else
                        <div class="table-responsive">
                            <table class="table align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-4">Sản phẩm</th>
                                        <th class="text-center">Giá</th>
                                        <th class="text-center">Số lượng</th>
                                        <th class="text-center">Tổng</th>
                                        <th class="text-end pe-4"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($cart as $id => $item)
                                    <tr>
                                        <td class="ps-4">
                                            <div class="d-flex align-items-center">
                                                <img src="{{ !empty($item['image']) ? BASE_URL . '/public/uploads/products/' . $item['image'] : 'https://www.google.com/search?q=https://placehold.co/80' }}" class="product-img me-3" alt="{{ $item['name'] }}">
                                                <div>
                                                    <h6 class="mb-0 fw-bold text-dark">{{ $item['name'] }}</h6>
                                                    <small class="text-muted">Mã SP: #{{ $id }}</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center">{{ number_format($item['price'], 0, ',', '.') }}đ</td>
                                        <td class="text-center">
                                            <div class="d-flex justify-content-center align-items-center">
                                                <form action="{{ BASE_URL }}/cart/updateQuantity" method="POST" class="d-flex align-items-center">
                                                    <input type="hidden" name="id" value="{{ $id }}">
                                                    <input type="number" name="quantity" class="form-control form-control-sm text-center" value="{{ $item['quantity'] }}" min="1" style="width: 60px;" onchange="this.form.submit()">
                                                </form>
                                            </div>
                                        </td>
                                        <td class="text-center fw-bold text-primary">
                                            {{ number_format($item['price'] * $item['quantity'], 0, ',', '.') }}đ
                                        </td>
                                        <td class="text-end pe-4">
                                            <a href="{{ BASE_URL }}/cart/remove/{{ $id }}" class="btn btn-sm btn-outline-danger border-0" onclick="return confirm('Xóa sản phẩm này khỏi giỏ hàng?')">
                                                <i class="bi bi-trash3"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <div class="p-3 bg-light d-flex justify-content-between">
                            <a href="{{ BASE_URL }}/" class="btn btn-link text-decoration-none text-dark p-0"><i class="bi bi-arrow-left me-1"></i> Tiếp tục mua sắm</a>
                            <a href="{{ BASE_URL }}/cart/clear" class="btn btn-link text-decoration-none text-danger p-0" onclick="return confirm('Xóa toàn bộ giỏ hàng?')">Xóa sạch giỏ hàng</a>
                        </div>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Tóm tắt và Mã giảm giá -->
            @if(!empty($cart))
            <div class="col-lg-4">
                <!-- Phần Mã giảm giá -->
                <div class="card shadow-sm mb-4">
                    <div class="card-body">
                        <h6 class="fw-bold mb-3">MÃ GIẢM GIÁ (COUPON)</h6>
                        @if(isset($_SESSION['success']))
                        <div class="alert alert-success py-2 small mb-2 border-0 shadow-sm">{{ $_SESSION['success'] }}</div>
                        @php unset($_SESSION['success']) @endphp
                        @endif
                        @if(isset($_SESSION['error']))
                        <div class="alert alert-danger py-2 small mb-2 border-0 shadow-sm">{{ $_SESSION['error'] }}</div>
                        @php unset($_SESSION['error']) @endphp
                        @endif

                        <form action="{{ BASE_URL }}/cart/applyCoupon" method="POST">
                            <div class="input-group">
                                <input type="text" name="coupon_code" class="form-control" placeholder="Nhập mã giảm giá..." value="{{ $coupon['code'] ?? '' }}">
                                <button class="btn btn-dark" type="submit">Áp dụng</button>
                            </div>
                        </form>
                        @if(isset($coupon))
                        <div class="mt-2 small text-success">
                            <i class="bi bi-check-circle-fill"></i> Đã áp dụng mã: <strong>{{ $coupon['code'] }}</strong>
                        </div>
                        @endif
                    </div>
                </div>

                <!-- Phần Tóm tắt thanh toán -->
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-4 text-center">TỔNG ĐƠN HÀNG</h5>

                        <div class="summary-item">
                            <span class="text-muted">Tạm tính:</span>
                            <span class="fw-bold text-dark">{{ number_format($subtotal, 0, ',', '.') }}đ</span>
                        </div>

                        <div class="summary-item text-success">
                            <span>Giảm giá:</span>
                            <span>-{{ number_format($discount, 0, ',', '.') }}đ</span>
                        </div>

                        <div class="summary-item">
                            <span class="text-muted">Phí vận chuyển:</span>
                            <span class="text-success fw-bold">Miễn phí</span>
                        </div>

                        <div class="summary-total d-flex justify-content-between align-items-center">
                            <span>Tổng cộng:</span>
                            <span class="text-primary fs-3">{{ number_format($total, 0, ',', '.') }}đ</span>
                        </div>

                        <p class="text-muted small mt-2 mb-4 text-center italic">
                            (Đã bao gồm thuế VAT nếu có)
                        </p>

                        <button class="btn btn-primary w-100 py-3 fw-bold shadow-sm" style="border-radius: 10px; font-size: 1.1rem;">
                            TIẾN HÀNH THANH TOÁN
                        </button>
                    </div>
                </div>
            </div>
            @endif
        </div>


    </div>

    <!-- Scripts -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>