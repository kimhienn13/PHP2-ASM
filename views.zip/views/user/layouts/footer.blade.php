</div> <!-- Đóng thẻ container py-5 từ Header -->

<footer class="bg-white border-top py-5 mt-auto">
<div class="container">
<div class="row g-4">
<!-- Thông tin thương hiệu -->
<div class="col-lg-4 col-md-6">
<h5 class="fw-bold text-primary mb-3">TECHMART</h5>
<p class="text-muted small">
Chuyên cung cấp các sản phẩm công nghệ chính hãng với chất lượng và dịch vụ hàng đầu Việt Nam.
</p>
<div class="d-flex gap-3 mt-3">
<a href="#" class="btn btn-outline-primary btn-sm rounded-circle shadow-sm"><i class="bi bi-facebook"></i></a>
<a href="#" class="btn btn-outline-danger btn-sm rounded-circle shadow-sm"><i class="bi bi-instagram"></i></a>
<a href="#" class="btn btn-outline-info btn-sm rounded-circle shadow-sm"><i class="bi bi-youtube"></i></a>
</div>
</div>

        <!-- Danh mục sản phẩm -->
        <div class="col-lg-2 col-md-6">
            <h6 class="fw-bold mb-3 text-dark">Sản phẩm</h6>
            <ul class="list-unstyled small">
                <li class="mb-2"><a href="#" class="text-muted text-decoration-none hover:text-primary transition-all">Điện thoại</a></li>
                <li class="mb-2"><a href="#" class="text-muted text-decoration-none hover:text-primary transition-all">Laptop</a></li>
                <li class="mb-2"><a href="#" class="text-muted text-decoration-none hover:text-primary transition-all">Phụ kiện</a></li>
            </ul>
        </div>

        <!-- Hỗ trợ khách hàng -->
        <div class="col-lg-3 col-md-6">
            <h6 class="fw-bold mb-3 text-dark">Hỗ trợ khách hàng</h6>
            <ul class="list-unstyled small">
                <li class="mb-2"><a href="#" class="text-muted text-decoration-none hover:text-primary transition-all">Chính sách bảo hành</a></li>
                <li class="mb-2"><a href="#" class="text-muted text-decoration-none hover:text-primary transition-all">Hướng dẫn mua hàng</a></li>
                <li class="mb-2"><a href="#" class="text-muted text-decoration-none hover:text-primary transition-all">Câu hỏi thường gặp</a></li>
            </ul>
        </div>

        <!-- Đăng ký nhận tin -->
        <div class="col-lg-3 col-md-6">
            <h6 class="fw-bold mb-3 text-dark">Bản tin</h6>
            <p class="text-muted small mb-3">Đăng ký để nhận tin ưu đãi mới nhất từ TechMart.</p>
            <div class="input-group input-group-sm">
                <input type="email" class="form-control border-secondary-subtle shadow-none" placeholder="Email của bạn">
                <button class="btn btn-primary px-3 shadow-none" type="button">Gửi</button>
            </div>
        </div>
    </div>
    
    <hr class="my-4 text-secondary opacity-25">
    
    <!-- Bản quyền & Thanh toán -->
    <div class="row align-items-center">
        <div class="col-md-6 text-center text-md-start">
            <p class="text-muted small mb-0">&copy; 2026 TechMart Store. Tất cả quyền được bảo lưu.</p>
        </div>
        <div class="col-md-6 text-center text-md-end mt-3 mt-md-0">
            <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" height="15" class="me-3 opacity-75 grayscale hover:grayscale-0 transition-all cursor-pointer">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" height="15" class="opacity-75 grayscale hover:grayscale-0 transition-all cursor-pointer">
        </div>
    </div>
</div>


</footer>

<!-- JS của Bootstrap 5 Bundle (Cần thiết để chạy Dropdown và Mobile Menu) -->

<script src="https://www.google.com/search?q=https://cdn.jsdelivr.net/npm/bootstrap%405.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>