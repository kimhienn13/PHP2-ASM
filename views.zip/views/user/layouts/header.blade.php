<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'TechMart' }}</title>

    <!-- Bootstrap + Icons + Font -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
        }
        .navbar-user {
            background: #fff;
            border-bottom: 1px solid #e5e7eb;
            padding: 14px 0;
        }
        .navbar-brand {
            color: #2563eb !important;
            font-weight: 700;
        }
        .nav-link {
            color: #334155 !important;
            font-weight: 600;
            padding: 10px 18px !important;
            text-transform: uppercase;
            border-radius: 999px;
        }
        .nav-link:hover {
            background: #eff6ff;
            color: #2563eb !important;
        }
        .cart-badge {
            font-size: 0.65rem;
            top: 4px !important;
        }
        .dropdown-menu {
            border-radius: 14px;
            border: none;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,.15);
        }
        .btn-auth {
            border-radius: 999px;
            font-weight: 700;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-user sticky-top shadow-sm">
    <div class="container">

        <!-- Logo -->
        <a class="navbar-brand d-flex align-items-center fs-3" href="{{ url('/') }}">
            <i class="bi bi-cpu-fill me-2"></i>TECHMART
        </a>

        <!-- Toggle -->
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#userMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="userMenu">

            <!-- Menu -->
            <ul class="navbar-nav me-auto ms-lg-4">
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('/product') }}">Sản phẩm</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('/coupon') }}">Mã giảm giá</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link position-relative" href="{{ url('/cart') }}">
                        Giỏ hàng
                        @if(session()->has('cart') && count(session('cart')) > 0)
                            <span class="position-absolute start-100 translate-middle badge rounded-pill bg-danger cart-badge">
                                {{ count(session('cart')) }}
                            </span>
                        @endif
                    </a>
                </li>
            </ul>

            <!-- User -->
            <ul class="navbar-nav ms-auto align-items-center">
                @if(session()->has('user'))
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle bg-light rounded-pill px-4" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i>
                            {{ session('user.fullname') }}
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            @if(session('user.role') === 'admin')
                                <li>
                                    <a class="dropdown-item fw-bold text-primary" href="{{ url('/admin') }}">
                                        <i class="bi bi-shield-lock me-2"></i>Quản trị
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                            @endif
                            <li>
                                <a class="dropdown-item fw-bold text-danger" href="{{ url('/logout') }}">
                                    <i class="bi bi-box-arrow-right me-2"></i>Đăng xuất
                                </a>
                            </li>
                        </ul>
                    </li>
                @else
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/login') }}">Đăng nhập</a>
                    </li>
                    <li class="nav-item ms-lg-2">
                        <a class="btn btn-primary btn-auth" href="{{ url('/register') }}">Đăng ký</a>
                    </li>
                @endif
            </ul>

        </div>
    </div>
</nav>
