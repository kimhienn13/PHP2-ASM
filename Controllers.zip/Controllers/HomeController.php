<?php

/**
 * HomeController xử lý các yêu cầu cho trang chủ của website
 */
class HomeController extends Controller {
    
    /**
     * Hiển thị danh sách sản phẩm mới nhất tại trang chủ
     * Đường dẫn: / hoặc /home hoặc /home/index
     */
    public function index() {
        // 1. Khởi tạo Model Product
        $productModel = $this->model('Product');
        
        /**
         * 2. Lấy danh sách sản phẩm
         * SỬA LỖI: Đổi từ $productModel->index() sang $productModel->list()
         * Vì Model Product của bạn sử dụng hàm list($page, $limit, $search, $filters)
         */
        $page = 1;      // Trang đầu tiên
        $limit = 10;    // Hiển thị 10 sản phẩm tại trang chủ
        $search = '';   // Không tìm kiếm mặc định
        $filters = [];  // Không có bộ lọc mặc định

        // Gọi hàm list từ Model Product (hàm này trả về mảng gồm data, total, totalPages)
        $result = $productModel->list($page, $limit, $search, $filters);
        
        // 3. Truyền dữ liệu sang View 'home/index'
        // Biến $products sẽ chứa mảng các bản ghi từ database
        $this->view('home/index', [
            'title'    => "Trang chủ - Thế giới công nghệ", 
            'products' => $result['data'] ?? []
        ]);
    }

    /**
     * Ví dụ về trang giới thiệu (nếu cần)
     */
    public function about() {
        $this->view('home/about', [
            'title' => 'Giới thiệu về chúng tôi'
        ]);
    }
}