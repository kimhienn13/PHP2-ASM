<?php

class CouponController extends Controller
{
    /**
     * Hiển thị danh sách Coupon
     */
    public function index()
    {
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $search = $_GET['search'] ?? '';
        $limit = 6;

        $couponModel = $this->model('Coupon');
        $result = $couponModel->list($page, $limit, $search);

        // Lấy baseUrl từ global hoặc hằng số định nghĩa ở bootstrap.php
        $baseUrl = $GLOBALS['baseUrl'] ?? '/PHP2';

        $this->view('coupon.index', [
            'title'       => 'Quản lý Mã giảm giá',
            'coupons'     => $result['data'],
            'totalPages'  => $result['totalPages'],
            'currentPage' => $page,
            'search'      => $search,
            'baseUrl'     => $baseUrl
        ]);
    }

    /**
     * API Lưu mã giảm giá mới (Trả về JSON)
     */
    public function store()
    {
        header('Content-Type: application/json');
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = strtoupper(trim($_POST['code'] ?? ''));
            $type = $_POST['type'] ?? 'percent';
            $value = (float)($_POST['value'] ?? 0);
            $status = isset($_POST['status']) ? 1 : 0;

            if (empty($code) || $value <= 0) {
                echo json_encode(['success' => false, 'message' => 'Vui lòng nhập đầy đủ thông tin!']);
                return;
            }

            $couponModel = $this->model('Coupon');
            if ($couponModel->exists($code)) {
                echo json_encode(['success' => false, 'message' => 'Mã giảm giá này đã tồn tại!']);
                return;
            }

            $couponModel->create([
                'code' => $code, 'type' => $type, 'value' => $value, 'status' => $status
            ]);

            echo json_encode(['success' => true, 'message' => 'Thêm thành công!']);
            return;
        }
    }

    /**
     * API Cập nhật mã giảm giá (Trả về JSON)
     */
    public function update($id)
    {
        header('Content-Type: application/json');
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $type = $_POST['type'] ?? 'percent';
            $value = (float)($_POST['value'] ?? 0);
            $status = isset($_POST['status']) ? 1 : 0;

            $couponModel = $this->model('Coupon');
            
            // Sử dụng named parameters (:type, :value...) để khớp với logic Model của bạn
            $sql = "UPDATE coupons SET type = :type, value = :value, status = :status WHERE id = :id";
            
            $couponModel->query($sql, [
                'type'   => $type,
                'value'  => $value,
                'status' => $status,
                'id'     => $id
            ]);

            echo json_encode(['success' => true, 'message' => 'Cập nhật thành công!']);
            return;
        }
    }

    /**
     * Xóa mã giảm giá
     */
    public function destroy($id)
    {
        $couponModel = $this->model('Coupon');
        $sql = "UPDATE coupons SET deleted_at = NOW() WHERE id = :id";
        $couponModel->query($sql, ['id' => $id]);
        
        $this->redirect('coupon/index?success=delete');
    }
}