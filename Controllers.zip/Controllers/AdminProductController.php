<?php

/**
 * ProductController xử lý các logic liên quan đến quản lý sản phẩm
 */
class ProductController extends Controller {
    
    /**
     * Hiển thị danh sách sản phẩm và chuẩn bị dữ liệu cho Modal Thêm/Sửa
     */
    public function index() {
        $productModel = $this->model('Product');
        
        // 1. Lấy các tham số lọc và tìm kiếm từ URL
        $search = $_GET['search'] ?? '';
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $price_filter = $_GET['price_filter'] ?? '';
        
        $filters = [];
        if ($price_filter === 'low') $filters['price <='] = 10000000;
        if ($price_filter === 'high') $filters['price >='] = 30000000;

        // 2. Lấy danh sách sản phẩm phân trang
        $result = $productModel->list($page, 5, $search, $filters);
        
        // 3. Lấy dữ liệu danh mục và thương hiệu để hiển thị trong dropdown của Modal
        // Lưu ý: Truyền đủ 3 đối số để tránh lỗi ArgumentCountError nếu Model yêu cầu
        $all_categories = $this->model('Category')->list(1, 100, '')['data'] ?? [];
        $all_brands = $this->model('Brand')->list(1, 100, '')['data'] ?? [];
        
        $this->view('product/index', [
            'products'       => $result['data'],
            'totalPages'     => $result['totalPages'],
            'currentPage'    => $page,
            'search'         => $search,
            'price_filter'   => $price_filter,
            'all_categories' => $all_categories,
            'all_brands'     => $all_brands,
            'title'          => 'Quản lý sản phẩm'
        ]);
    }

    /**
     * Xử lý thêm mới sản phẩm và upload ảnh
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $price = (float)($_POST['price'] ?? 0);
            $model = $this->model('Product');

            // 1. Ràng buộc: Giá không âm, tên không trống và không trùng
            if ($price < 0 || empty($name)) {
                $this->redirect('product/index?error=invalid_data');
                return;
            }

            if ($model->exists($name)) {
                $this->redirect('product/index?error=duplicate');
                return;
            }

            // 2. Xử lý tải tệp ảnh lên
            $imageName = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $imageName = $this->uploadFile($_FILES['image']);
            }

            // 3. Gọi hàm create của Model
            $model->create([
                'name'        => $name,
                'price'       => $price,
                'image'       => $imageName,
                'category_id' => !empty($_POST['category_id']) ? $_POST['category_id'] : null,
                'brand_id'    => !empty($_POST['brand_id']) ? $_POST['brand_id'] : null
            ]);

            $this->redirect('product/index');
        }
    }

    /**
     * Xử lý cập nhật sản phẩm (Sử dụng 2 tham số: ID và Data)
     */
    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $price = (float)($_POST['price'] ?? 0);
            $model = $this->model('Product');

            // 1. Kiểm tra tính hợp lệ của dữ liệu
            if ($price < 0 || empty($name)) {
                $this->redirect('product/index?error=invalid_data');
                return;
            }

            if ($model->exists($name, $id)) {
                $this->redirect('product/index?error=duplicate');
                return;
            }

            // 2. Lấy thông tin sản phẩm hiện tại để xử lý ảnh
            $currentProduct = $model->show($id);
            $imageName = $currentProduct['image'] ?? null;

            // 3. Xử lý nếu người dùng chọn file ảnh mới
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $newImage = $this->uploadFile($_FILES['image']);
                if ($newImage) {
                    $imageName = $newImage;
                }
            }

            // 4. Gọi hàm update của Model với 2 tham số như đã định nghĩa trong Canvas
            $model->update($id, [
                'name'        => $name,
                'price'       => $price,
                'image'       => $imageName,
                'category_id' => !empty($_POST['category_id']) ? $_POST['category_id'] : null,
                'brand_id'    => !empty($_POST['brand_id']) ? $_POST['brand_id'] : null
            ]);

            $this->redirect('product/index');
        }
    }

    /**
     * Xử lý xóa mềm sản phẩm
     */
    public function destroy($id) {
        $this->model('Product')->delete($id);
        $this->redirect('product/index');
    }

    /**
     * Hàm hỗ trợ tải file lên thư mục public/uploads/products/
     * @param array $file Biến $_FILES['image']
     * @return string|null Tên file đã lưu hoặc null nếu thất bại
     */
    private function uploadFile($file) {
        // Sử dụng hằng số BASE_PATH từ bootstrap.php
        $targetDir = BASE_PATH . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'products' . DIRECTORY_SEPARATOR;
        
        // Tạo thư mục nếu chưa tồn tại
        if (!file_exists($targetDir)) {
            mkdir($targetDir, 0777, true);
        }

        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (in_array($extension, $allowed)) {
            $fileName = uniqid('prod_', true) . '.' . $extension;
            $targetPath = $targetDir . $fileName;

            if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                return $fileName;
            }
        }
        return null;
    }
}