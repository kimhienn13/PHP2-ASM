<?php

class AuthController extends Controller {
    
    /**
     * Hiển thị trang đăng nhập
     */
    public function login() {
        $this->view('auth.login', ['title' => 'Đăng nhập hệ thống']);
    }

    /**
     * Xử lý đăng nhập người dùng
     */
    public function postLogin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            if (empty($email) || empty($password)) {
                $_SESSION['error'] = 'Vui lòng nhập đầy đủ email và mật khẩu!';
                $this->redirect('auth/login');
            }

            $userModel = $this->model('User');
            $user = $userModel->findByEmail($email);

            if ($user && password_verify($password, $user['password'])) {
                // Lưu thông tin người dùng vào session sau khi xác thực thành công
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'fullname' => $user['fullname'],
                    'email' => $user['email']
                ];
                
                $_SESSION['success'] = 'Chào mừng ' . $user['fullname'] . ' quay trở lại!';
                $this->redirect('home/index');
            } else {
                $_SESSION['error'] = 'Email hoặc mật khẩu không chính xác!';
                $this->redirect('auth/login');
            }
        }
    }

    /**
     * Hiển thị trang đăng ký
     */
    public function register() {
        $this->view('auth.register', ['title' => 'Đăng ký tài khoản mới']);
    }

    /**
     * Xử lý đăng ký thành viên mới
     */
    public function postRegister() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $fullname = trim($_POST['fullname'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            if (empty($fullname) || empty($email) || empty($password)) {
                $_SESSION['error'] = 'Vui lòng nhập đầy đủ thông tin đăng ký!';
                $this->redirect('auth/register');
                return;
            }

            $userModel = $this->model('User');
            if ($userModel->exists($email)) {
                $_SESSION['error'] = 'Địa chỉ email này đã được sử dụng!';
                $this->redirect('auth/register');
                return;
            }

            // Tạo tài khoản mới (Mật khẩu sẽ được hash tự động trong Model)
            $userModel->create([
                'fullname' => $fullname,
                'email' => $email,
                'password' => $password
            ]);

            $_SESSION['success'] = 'Đăng ký thành công! Vui lòng đăng nhập.';
            $this->redirect('auth/login');
        }
    }

    /**
     * Hiển thị trang quên mật khẩu
     */
    public function forgot() {
        $this->view('auth.forgot', ['title' => 'Khôi phục mật khẩu']);
    }

    /**
     * Xử lý khôi phục/đổi mật khẩu mới
     */
    public function postForgot() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $newPassword = $_POST['password'] ?? '';

            if (empty($email) || empty($newPassword)) {
                $_SESSION['error'] = 'Vui lòng nhập đầy đủ thông tin!';
                $this->redirect('auth/forgot');
                return;
            }

            $userModel = $this->model('User');
            if ($userModel->exists($email)) {
                // Cập nhật mật khẩu mới thông qua model
                $userModel->updatePassword($email, $newPassword);
                
                $_SESSION['success'] = 'Cập nhật mật khẩu thành công! Hãy đăng nhập lại.';
                $this->redirect('auth/login');
            } else {
                $_SESSION['error'] = 'Tài khoản với email này không tồn tại trên hệ thống!';
                $this->redirect('auth/forgot');
            }
        }
    }

    /**
     * Đăng xuất khỏi hệ thống
     */
    public function logout() {
        unset($_SESSION['user']);
        $_SESSION['success'] = 'Bạn đã đăng xuất thành công.';
        $this->redirect('auth/login');
    }
}