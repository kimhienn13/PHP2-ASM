<?php

/**
 * BrandController xử lý logic cho thương hiệu
 */
class BrandController extends Controller {

    public function index() {
        $search = $_GET['search'] ?? '';
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 5;

        $model = $this->model('Brand');
        $result = $model->list($page, $limit, $search);

        $this->view('brand/index', [
            'brands'      => $result['data'] ?? [],
            'totalPages'  => $result['totalPages'] ?? 0,
            'currentPage' => $page,
            'search'      => $search,
            'title'       => 'Quản lý thương hiệu'
        ]);
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $model = $this->model('Brand');

            if (empty($name)) {
                $this->redirect('brand/index?error=invalid_data');
                return;
            }

            if ($model->exists($name)) {
                $this->redirect('brand/index?error=duplicate');
                return;
            }

            $image = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $image = $this->uploadFile($_FILES['image']);
            }

            $model->create([
                'name'        => $name,
                'description' => $description,
                'image'       => $image
            ]);

            $this->redirect('brand/index');
        }
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $model = $this->model('Brand');

            if (empty($name)) {
                $this->redirect('brand/index?error=invalid_data');
                return;
            }

            if ($model->exists($name, $id)) {
                $this->redirect('brand/index?error=duplicate');
                return;
            }

            $brand = $model->show($id);
            $image = $brand['image'] ?? null;

            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $newImage = $this->uploadFile($_FILES['image']);
                if ($newImage) $image = $newImage;
            }

            $model->update($id, [
                'name'        => $name,
                'description' => $description,
                'image'       => $image
            ]);

            $this->redirect('brand/index');
        }
    }

    public function destroy($id) {
        $this->model('Brand')->delete($id);
        $this->redirect('brand/index');
    }

    private function uploadFile($file) {
        $dir = BASE_PATH . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'brands' . DIRECTORY_SEPARATOR;
        if (!file_exists($dir)) mkdir($dir, 0777, true);
        
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $fileName = uniqid('brand_', true) . '.' . $ext;
        
        if (move_uploaded_file($file['tmp_name'], $dir . $fileName)) {
            return $fileName;
        }
        return null;
    }
}