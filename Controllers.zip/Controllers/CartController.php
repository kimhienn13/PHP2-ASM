<?php

class CartController extends Controller {
    
    public function index() {
        $cart = $_SESSION['cart'] ?? [];
        $coupon = $_SESSION['coupon'] ?? null;
        
        $subtotal = 0;
        foreach ($cart as $item) {
            $subtotal += $item['price'] * $item['quantity'];
        }

        $discount = 0;
        if ($coupon) {
            $discount = ($coupon['type'] == 'percent') 
                ? ($subtotal * $coupon['value'] / 100) 
                : $coupon['value'];
        }

        $this->view('cart.index', [
            'title' => 'Giỏ hàng của bạn',
            'cart' => $cart,
            'subtotal' => $subtotal,
            'discount' => $discount,
            'total' => max(0, $subtotal - $discount),
            'coupon' => $coupon
        ]);
    }

    public function add($id) {
        $productModel = $this->model('Product');
        $product = $productModel->show($id);
        
        if ($product) {
            if (!isset($_SESSION['cart'][$id])) {
                $_SESSION['cart'][$id] = [
                    'id' => $product['id'],
                    'name' => $product['name'],
                    'price' => $product['price'],
                    'image' => $product['image'],
                    'quantity' => 1
                ];
            } else {
                $_SESSION['cart'][$id]['quantity']++;
            }
        }
        $this->redirect('cart/index');
    }

    public function applyCoupon() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = strtoupper(trim($_POST['coupon_code'] ?? ''));
            $couponModel = $this->model('Coupon');
            $coupon = $couponModel->findByCode($code);
            
            if ($coupon) {
                $_SESSION['coupon'] = [
                    'code' => $coupon['code'],
                    'type' => $coupon['type'],
                    'value' => $coupon['value']
                ];
                $_SESSION['success'] = 'Áp dụng mã giảm giá thành công!';
            } else {
                $_SESSION['error'] = 'Mã giảm giá không hợp lệ!';
                unset($_SESSION['coupon']);
            }
            $this->redirect('cart/index');
        }
    }

    public function remove($id) {
        unset($_SESSION['cart'][$id]);
        $this->redirect('cart/index');
    }

    public function updateQuantity() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'];
            $qty = (int)$_POST['quantity'];
            if ($qty > 0 && isset($_SESSION['cart'][$id])) {
                $_SESSION['cart'][$id]['quantity'] = $qty;
            }
            $this->redirect('cart/index');
        }
    }
}