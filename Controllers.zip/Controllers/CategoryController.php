<?php

/**
 * CategoryController xử lý logic cho danh mục
 */
class CategoryController extends Controller {

    /**
     * Hiển thị danh sách danh mục
     */
    public function index() {
        $search = $_GET['search'] ?? '';
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 5;

        $model = $this->model('Category');
        $result = $model->list($page, $limit, $search);

        $this->view('category/index', [
            'categories'  => $result['data'] ?? [],
            'totalPages'  => $result['totalPages'] ?? 0,
            'currentPage' => $page,
            'search'      => $search,
            'title'       => 'Quản lý danh mục'
        ]);
    }

    /**
     * Xử lý thêm mới danh mục
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $model = $this->model('Category');
            
            $name = trim($_POST['name'] ?? '');
            $imageName = null;

            // 1. Ràng buộc: Không trùng tên
            if ($model->isDuplicate($name)) {
                $this->redirect('category/index?error=duplicate');
                return;
            }

            // 2. Xử lý tải tệp ảnh (File Upload)
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $imageName = $this->uploadFile($_FILES['image']);
            }

            $model->create([
                'name'  => $name,
                'image' => $imageName
            ]);

            $this->redirect('category/index');
        }
    }

    /**
     * Xử lý cập nhật danh mục
     */
    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $model = $this->model('Category');
            
            $name = trim($_POST['name'] ?? '');
            
            // Lấy thông tin cũ để giữ lại ảnh nếu không upload ảnh mới
            $oldCategory = $model->show($id);
            $imageName = $oldCategory['image'] ?? null;

            // 1. Ràng buộc: Không trùng tên (loại trừ danh mục hiện tại)
            if ($model->isDuplicate($name, $id)) {
                $this->redirect('category/index?error=duplicate');
                return;
            }

            // 2. Xử lý tải tệp ảnh mới (nếu có)
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $newImage = $this->uploadFile($_FILES['image']);
                if ($newImage) {
                    $imageName = $newImage;
                    // Bạn có thể thêm logic xóa file cũ tại đây nếu muốn
                }
            }

            $model->update($id, [
                'name'  => $name,
                'image' => $imageName
            ]);

            $this->redirect('category/index');
        }
    }

    /**
     * Xử lý xóa mềm danh mục
     */
    public function destroy($id) {
        $this->model('Category')->delete($id);
        $this->redirect('category/index');
    }

    /**
     * Hàm hỗ trợ tải tệp ảnh lên thư mục public/uploads/categories/
     */
    private function uploadFile($file) {
        $targetDir = BASE_PATH . "/public/uploads/categories/";
        
        // Tạo thư mục nếu chưa tồn tại
        if (!file_exists($targetDir)) {
            mkdir($targetDir, 0777, true);
        }

        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (in_array($fileExtension, $allowedExtensions)) {
            // Tạo tên file duy nhất để tránh trùng
            $newFileName = uniqid('cat_', true) . '.' . $fileExtension;
            $targetFile = $targetDir . $newFileName;

            if (move_uploaded_file($file['tmp_name'], $targetFile)) {
                return $newFileName;
            }
        }
        return null;
    }
}