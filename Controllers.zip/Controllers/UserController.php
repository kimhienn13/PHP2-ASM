<?php

class UserController extends Controller
{
    /**
     * Hiển thị danh sách thành viên - Phân trang 6 mục/trang
     * Trang này tự chứa giao diện (Standalone), không cần layout.app
     */
    public function index()
    {
        // Lấy trang hiện tại và từ khóa tìm kiếm
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $search = $_GET['search'] ?? '';
        $limit = 6; // Yêu cầu hiển thị 6 mục trên 1 trang

        $userModel = $this->model('User');
        
        // Gọi hàm list từ User Model (đã hỗ trợ paginate)
        $result = $userModel->list($page, $limit, $search);

        // Trả về view với dữ liệu phân trang
        $this->view('user.index', [
            'title'       => 'Hệ thống Quản lý Thành viên',
            'users'       => $result['data'],
            'totalPages'  => $result['totalPages'],
            'currentPage' => $page,
            'search'      => $search
        ]);
    }

    /**
     * Thêm mới thành viên
     */
    public function store()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'fullname' => trim($_POST['fullname'] ?? ''),
                'email'    => trim($_POST['email'] ?? ''),
                'password' => $_POST['password'] ?? '123456'
            ];

            if (empty($data['fullname']) || empty($data['email'])) {
                $this->redirect('user/index?error=invalid_data');
            }

            $userModel = $this->model('User');
            if ($userModel->exists($data['email'])) {
                $this->redirect('user/index?error=duplicate');
            }

            $userModel->create($data);
            $this->redirect('user/index?success=add');
        }
    }

    /**
     * Cập nhật thành viên
     */
    public function update($id)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $fullname = trim($_POST['fullname'] ?? '');
            $email = trim($_POST['email'] ?? '');

            $userModel = $this->model('User');
            if ($userModel->exists($email, $id)) {
                $this->redirect('user/index?error=duplicate');
            }

            $sql = "UPDATE users SET fullname = ?, email = ? WHERE id = ?";
            $userModel->query($sql, [$fullname, $email, $id]);

            $this->redirect('user/index?success=update');
        }
    }

    /**
     * Xóa thành viên
     */
    public function destroy($id)
    {
        $userModel = $this->model('User');
        $sql = "UPDATE users SET deleted_at = NOW() WHERE id = ?";
        $userModel->query($sql, [$id]);
        $this->redirect('user/index?success=delete');
    }
}