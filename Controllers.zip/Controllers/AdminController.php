<?php

/**
 * Controller cơ sở cho tất cả các trang quản trị
 * File này đảm bảo an ninh cho toàn bộ hệ thống Admin
 */
class AdminController extends Controller {
    public function __construct() {
        // Kiểm tra xem người dùng đã đăng nhập chưa và có phải admin không
        if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] ?? '') !== 'admin') {
            // Nếu không phải admin, đẩy ra trang login kèm thông báo lỗi
            $_SESSION['error'] = "Khu vực này chỉ dành cho Quản trị viên!";
            $this->redirect('auth/login');
        }
    }
}